
import asyncio
import json
import logging
import platform
import numpy as np
import cv2
import pyrealsense2 as rs


from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from av import VideoFrame


class RealSenseTrack(VideoStreamTrack):
    """
    一个从 Intel RealSense D435 相机捕获视频的视频轨道。
    """
    def __init__(self):
        super().__init__()
        logging.info("Initializing RealSense D435...")
        self.pipeline = rs.pipeline()
        config = rs.config()
        
        # 获取设备产品线，以确定是否为 D400 系列
        pipeline_wrapper = rs.pipeline_wrapper(self.pipeline)
        pipeline_profile = config.resolve(pipeline_wrapper)
        device = pipeline_profile.get_device()
        
        # 找到彩色传感器
        color_sensor = None
        for s in device.sensors:
            if s.get_info(rs.camera_info.name) == 'RGB Camera':
                color_sensor = s
                break
        if not color_sensor:
            logging.error("Could not find RGB Camera sensor.")
            exit()

        # 配置流的分辨率和帧率
        # 你可以根据需要修改，例如 1280x720@30fps
        self.width, self.height, self.fps = 640, 480, 30
        config.enable_stream(rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps)
        
        # 启动管道
        self.profile = self.pipeline.start(config)
        logging.info(f"RealSense D435 started at {self.width}x{self.height}@{self.fps}fps")

    async def recv(self):
        """
        这个方法由 aiortc 内部循环调用，以获取新的视频帧。
        """
        # 等待一对连贯的帧: 深度和颜色
        try:
            frames = self.pipeline.wait_for_frames()
            color_frame = frames.get_color_frame()
            if not color_frame:
                print("没有颜色帧")
                return None

            # 将图像数据转换为 numpy 数组
            img = np.asanyarray(color_frame.get_data())
            print(f"视频帧大小: {img.shape}, 数据类型: {img.dtype}")

            if img.size == 0:
                print("图像数据为空")
                return None

            # 将 numpy 数组转换为 av.VideoFrame
            # RealSense 默认输出 BGR 格式，WebRTC 需要 BGR24 或其他格式
            # 我们在这里直接使用 BGR8 -> bgr24
            frame = VideoFrame.from_ndarray(img, format="bgr24")
            
            # 设置时间戳，这对于同步非常重要
            pts, time_base = await self.next_timestamp()
            frame.pts = pts
            frame.time_base = time_base
            
            return frame

        except Exception as e:
            print(f"视频帧处理错误: {e}")
            return None

    def stop(self):
        """
        停止 RealSense 管道
        """
        logging.info("Stopping RealSense D435...")
        self.pipeline.stop()



class D435WebRTC():
    def __init__(self,mqtt_client):
        self.mqtt_client = mqtt_client
        self.pcs = set()
        
         # 存储所有 RTCPeerConnection 实例
    async def offer(self,data):
        """
        处理来自 Web 客户端的 HTTP POST 请求。
        请求体中包含客户端的 SDP Offer。
        """
        
        params = data
        offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

        pc = RTCPeerConnection()
        self.pcs.add(pc)
        print("RTCPeerConnection 已创建")

        @pc.on("connectionstatechange")
        async def on_connectionstatechange():
            logging.info(f"Connection state is {pc.connectionState}")
            if pc.connectionState == "failed" or pc.connectionState == "closed":
                await pc.close()
                self.pcs.discard(pc)
                logging.info("Connection closed.")

        # 创建并添加 D435 视频轨道
        # 这个客户端只推流，所以只 addTrack
        video_track = RealSenseTrack()
        pc.addTrack(video_track)
        print("视频轨道已添加")

        # 设置远程描述 (来自客户端的 Offer)
        await pc.setRemoteDescription(offer)

        # 创建应答 (Answer)
        answer = await pc.createAnswer()
        
        # 设置本地描述 (我们自己的 Answer)
        await pc.setLocalDescription(answer)

        self.mqtt_client.publish("webrtc/answer"+"/"+data["uuid"], json.dumps({"type": "rtcanswer",                                                        
                                                        "sdp": pc.localDescription.sdp, 
                                                        "type": pc.localDescription.type}),
                                                        qos=2,retain=False)
        
                                         
    
    
    
    